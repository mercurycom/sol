<?php

$BACKEND_HOST = "localhost:80";
$BACKEND_PROTOCOL = "http";
$BACKEND_KEYCODE = "";
$GROUP_CHAT_ID = "";
$IS_CLOUDFLARED = false;